package Interfaces;

import javax.swing.table.TableModel;

public interface ViewDAO {
	public TableModel ProfitableShowsView();
	public TableModel PrimeTimeView();
	public TableModel PrimeTimeRoomsView();
}
