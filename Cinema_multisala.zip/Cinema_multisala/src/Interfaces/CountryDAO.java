package Interfaces;

import java.util.List;

import Entity.Country;

public interface CountryDAO {
	public List<Country> getCountries();
}
