package Interfaces;

import java.util.List;

import Entity.Audio;

public interface AudioDAO {
	public List<Audio> getAudios();
}
