package Interfaces;

import java.sql.Connection;

public interface ConnectiondbDAO {
	public Connection get_connection();
}
